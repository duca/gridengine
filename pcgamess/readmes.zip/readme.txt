Please see the following files for important information:

PC GAMESS reference:
  readme.reference

Command line options:
  readme.commandline

Pentium 4-specific PC GAMESS versions notes:
  readme.p4

OS/2 PC GAMESS versions notes:
  readme.os2

Linux PC GAMESS versions notes:
  readme.linux

Spherical basis sets and PC GAMESS:
  readme.spherical

PC GAMESS' fast 2-electron integral code for direct runs:
  readme.fastints

PC GAMESS' linear scaling SCF methods:
  readme.qfmm

PC GAMESS' DFT implementation:
  readme.dft

PC GAMESS' TDDFT implementation:
  readme.tddft

PC GAMESS' TDHF (RPA) implementation:
  readme.tdhf

PC GAMESS' CI-singles (CIS) implementation:
  readme.cis

Notes on large-scale MCSCF calculations:
  readme.mcscf

PC GAMESS' cube feature implementation:
  readme.cube

PC GAMESS' fastdiag feature:
  readme.fastdiag

Parallel PC GAMESS, Windows:
  readme.bindings
  readme.parallel.windows.wmpi
  readme.parallel.windows.nt-mpich
  readme.parallel.windows.nt-mpich-smp
  readme.parallel.windows.mpich.nt

Parallel PC GAMESS, Linux:
  readme.parallel.linux.mpich
  readme.parallel.linux.lam

Parallel PC GAMESS P2P interface:
  readme.p2p

Please see URL http://classic.chem.msu.su/gran/gamess/index.html
for any additional information concerning the current PC GAMESS versions
